import * as React from "react";
import { Slot } from "@radix-ui/react-slot";
import { cva, type VariantProps } from "class-variance-authority";

import { cn } from "@/lib/utils";

/**
 * BUTTON SYSTEM — design rules (do NOT bypass with manual h-* classes):
 *
 * VARIANT (hierarchy on a page/dialog):
 *   default      — primary action (1 per surface): Save, Submit, Register, Close Shift
 *   secondary    — alternate primary
 *   outline      — neutral controls: filters, toggles, refresh, export
 *   ghost        — icon-only buttons inside tables/headers; close
 *   destructive  — only delete / block / blacklist
 *   link         — inline navigation
 *
 * SIZE (height tokens):
 *   default      — h-10  (forms, dialogs)        — main forms / modal CTAs
 *   compact      — h-9   (page chrome, filters, table actions)
 *   sm           — h-9   (alias of compact, kept for backwards compat)
 *   xs           — h-8   (very dense rows / chip toolbars)
 *   lg           — h-11  (auth screens, big CTAs only)
 *   icon         — h-10 w-10 (square, paired with default-height surfaces)
 *   icon-sm      — h-9 w-9  (paired with compact surfaces / inside tables)
 *   icon-xs      — h-8 w-8  (paired with xs surfaces)
 */
const buttonVariants = cva(
  "inline-flex items-center justify-center gap-2 whitespace-nowrap rounded-md text-sm font-medium ring-offset-background transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:pointer-events-none disabled:opacity-50 [&_svg]:pointer-events-none [&_svg]:size-4 [&_svg]:shrink-0",
  {
    variants: {
      variant: {
        default: "border border-primary bg-transparent text-primary hover:bg-primary hover:text-primary-foreground",
        destructive: "bg-destructive text-destructive-foreground hover:bg-destructive/90",
        outline: "border border-input bg-background hover:bg-accent hover:text-accent-foreground",
        secondary: "bg-secondary text-secondary-foreground hover:bg-secondary/80",
        ghost: "hover:bg-accent hover:text-accent-foreground",
        link: "text-primary underline-offset-4 hover:underline",
      },
      size: {
        default: "h-[var(--density-btn,2.5rem)] px-[var(--density-px,1rem)] py-2",
        compact: "h-9 rounded-md px-3",
        sm: "h-9 rounded-md px-3",
        xs: "h-8 rounded-md px-2.5 text-xs",
        lg: "h-11 rounded-md px-8",
        icon: "h-10 w-10",
        "icon-sm": "h-9 w-9",
        "icon-xs": "h-8 w-8",
      },
    },
    defaultVariants: {
      variant: "default",
      size: "default",
    },
  },
);

export interface ButtonProps
  extends React.ButtonHTMLAttributes<HTMLButtonElement>,
    VariantProps<typeof buttonVariants> {
  asChild?: boolean;
}

const Button = React.forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant, size, asChild = false, ...props }, ref) => {
    const Comp = asChild ? Slot : "button";
    return <Comp className={cn(buttonVariants({ variant, size, className }))} ref={ref} {...props} />;
  },
);
Button.displayName = "Button";

export { Button, buttonVariants };
